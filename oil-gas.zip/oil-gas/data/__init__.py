"""Data package with lazy imports for optional dataset dependencies."""

from importlib import import_module


_EXPORTS = {
    "SeismicWellDataset": (".dataset", "SeismicWellDataset"),
    "PretrainDataset": (".dataset", "PretrainDataset"),
    "FinetuneDataset": (".dataset", "FinetuneDataset"),
    "SeismicAugmentation": (".transforms", "SeismicAugmentation"),
    "WellLogAugmentation": (".transforms", "WellLogAugmentation"),
    "SyntheticDataGenerator": (".synthetic_data", "SyntheticDataGenerator"),
    "WellLogFolderDataset": (".well_log_folder_dataset", "WellLogFolderDataset"),
    "discover_las_files": (".well_log_folder_dataset", "discover_las_files"),
}

__all__ = list(_EXPORTS)


def __getattr__(name):
    if name not in _EXPORTS:
        raise AttributeError(f"module {__name__!r} has no attribute {name!r}")
    module_name, attribute_name = _EXPORTS[name]
    value = getattr(import_module(module_name, __name__), attribute_name)
    globals()[name] = value
    return value
