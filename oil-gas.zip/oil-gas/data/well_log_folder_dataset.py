"""Well-log-only dataset for pretraining directly from LAS folders."""

from __future__ import annotations

from collections import OrderedDict
from pathlib import Path
from typing import Dict, Iterable, List, Sequence, Tuple

import numpy as np
import torch
from torch.utils.data import Dataset

from .prepare_volve_data import STANDARD_CURVES
from .volve_dataset import LASWellLoader


RESISTIVITY_CURVES = frozenset({"RD", "MLL", "MSFL"})


def discover_las_files(roots: Iterable[str | Path]) -> List[Path]:
    files = set()
    for raw_root in roots:
        root = Path(raw_root).expanduser().resolve()
        if root.is_file() and root.suffix.lower() == ".las":
            files.add(root)
        elif root.is_dir():
            files.update(p.resolve() for p in root.rglob("*.las"))
            files.update(p.resolve() for p in root.rglob("*.LAS"))
    return sorted(files)


class WellLogFolderDataset(Dataset):
    """Create fixed-depth windows from a collection of standardized LAS files."""

    def __init__(
        self,
        las_files: Sequence[str | Path],
        sequence_length: int = 128,
        stride: int = 64,
        min_curves: int = 2,
        cache_size: int = 8,
    ) -> None:
        super().__init__()
        self.las_files = [Path(p).expanduser().resolve() for p in las_files]
        self.sequence_length = sequence_length
        self.stride = stride
        self.min_curves = min_curves
        self.cache_size = cache_size
        self.loader = LASWellLoader()
        self._cache: OrderedDict[Path, Dict[str, np.ndarray]] = OrderedDict()
        self.samples: List[Tuple[Path, int]] = []
        self.file_summary: List[Dict] = []
        self._build_index()

    def _read(self, path: Path) -> Dict[str, np.ndarray]:
        if path in self._cache:
            data = self._cache.pop(path)
            self._cache[path] = data
            return data
        data = self.loader.read(str(path))
        self._cache[path] = data
        while len(self._cache) > self.cache_size:
            self._cache.popitem(last=False)
        return data

    def _build_index(self) -> None:
        for path in self.las_files:
            data = self.loader.read(str(path))
            depth = np.asarray(data.get("depth", []))
            n = int(depth.size)
            available = [
                curve for curve in STANDARD_CURVES
                if curve in data and np.isfinite(data[curve]).any()
            ]
            if n < self.sequence_length or len(available) < self.min_curves:
                continue
            starts = list(range(0, n - self.sequence_length + 1, self.stride))
            self.samples.extend((path, start) for start in starts)
            self.file_summary.append({
                "path": str(path),
                "samples": n,
                "windows": len(starts),
                "curves": available,
            })

        if not self.samples:
            raise ValueError(
                "No usable LAS windows found. Check --las-roots, sequence length, and curve aliases."
            )

    @staticmethod
    def _transform_curve(curve: str, values: np.ndarray) -> Tuple[np.ndarray, np.ndarray]:
        values = values.astype(np.float32, copy=True)
        valid = np.isfinite(values)
        if curve in RESISTIVITY_CURVES:
            valid &= values > 0
            values[valid] = np.log10(np.clip(values[valid], 1e-4, None))
        values[~valid] = 0.0
        return values, valid

    def __len__(self) -> int:
        return len(self.samples)

    def __getitem__(self, index: int) -> Dict[str, torch.Tensor | str | int]:
        path, start = self.samples[index]
        data = self._read(path)
        end = start + self.sequence_length

        curves, value_masks = [], []
        for curve in STANDARD_CURVES:
            if curve in data:
                raw = np.asarray(data[curve][start:end])
                values, valid = self._transform_curve(curve, raw)
            else:
                values = np.zeros(self.sequence_length, dtype=np.float32)
                valid = np.zeros(self.sequence_length, dtype=bool)
            curves.append(values)
            value_masks.append(valid.astype(np.float32))

        well_log = np.stack(curves)
        value_mask = np.stack(value_masks)
        curve_mask = value_mask.any(axis=1).astype(np.float32)
        depth_mask = value_mask.any(axis=0).astype(np.float32)

        return {
            "well_log": torch.from_numpy(well_log).float(),
            "curve_mask": torch.from_numpy(curve_mask).float(),
            "value_mask": torch.from_numpy(value_mask).float(),
            "well_mask": torch.from_numpy(depth_mask).float(),
            "las_path": str(path),
            "depth_start": start,
        }
