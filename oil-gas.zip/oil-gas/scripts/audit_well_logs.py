"""Audit LAS curve coverage and value ranges before well-log pretraining."""

import argparse
import csv
import sys
from pathlib import Path

import numpy as np

sys.path.insert(0, str(Path(__file__).parent.parent))

from data.prepare_volve_data import STANDARD_CURVES
from data.volve_dataset import LASWellLoader


def discover_las(inputs):
    files = []
    for raw in inputs:
        path = Path(raw).expanduser()
        if path.is_file() and path.suffix.lower() == ".las":
            files.append(path)
        elif path.is_dir():
            files.extend(path.rglob("*.las"))
            files.extend(path.rglob("*.LAS"))
    return sorted(set(path.resolve() for path in files))


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("inputs", nargs="+", help="LAS files or directories")
    parser.add_argument("--output", help="Optional CSV report path")
    args = parser.parse_args()

    las_files = discover_las(args.inputs)
    if not las_files:
        raise SystemExit("No LAS files found.")

    loader = LASWellLoader()
    rows = []
    for path in las_files:
        data = loader.read(str(path))
        depth = np.asarray(data.get("depth", []))
        n = int(depth.size)
        for curve in STANDARD_CURVES:
            values = np.asarray(data.get(curve, []), dtype=np.float64)
            finite = values[np.isfinite(values)]
            rows.append({
                "file": str(path),
                "curve": curve,
                "samples": n,
                "valid_samples": int(finite.size),
                "coverage": float(finite.size / n) if n else 0.0,
                "p01": float(np.percentile(finite, 1)) if finite.size else "",
                "median": float(np.median(finite)) if finite.size else "",
                "p99": float(np.percentile(finite, 99)) if finite.size else "",
            })

    print("file,curve,samples,valid_samples,coverage,p01,median,p99")
    for row in rows:
        print(
            f"{Path(row['file']).name},{row['curve']},{row['samples']},"
            f"{row['valid_samples']},{row['coverage']:.3f},"
            f"{row['p01']},{row['median']},{row['p99']}"
        )

    if args.output:
        output = Path(args.output).expanduser()
        output.parent.mkdir(parents=True, exist_ok=True)
        with output.open("w", newline="", encoding="utf-8") as handle:
            writer = csv.DictWriter(handle, fieldnames=rows[0].keys())
            writer.writeheader()
            writer.writerows(rows)
        print(f"Wrote: {output.resolve()}")


if __name__ == "__main__":
    main()
