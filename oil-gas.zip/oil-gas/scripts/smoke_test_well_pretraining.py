"""Small CPU/GPU smoke test for WLFM continuous masked reconstruction."""

import argparse
import math
import sys
from pathlib import Path

import torch

sys.path.insert(0, str(Path(__file__).parent.parent))

from models.wlfm_well_log_encoder import WLFMWellLogEncoder1D


def build_batch(batch_size: int, num_curves: int, length: int, device: str):
    depth = torch.linspace(0, 8 * math.pi, length, device=device)
    latent = torch.sin(depth)[None, None, :].repeat(batch_size, 1, 1)
    curve_scale = torch.linspace(0.5, 1.5, num_curves, device=device)[None, :, None]
    curve_bias = torch.linspace(-0.5, 0.5, num_curves, device=device)[None, :, None]
    logs = latent * curve_scale + curve_bias + 0.03 * torch.randn(
        batch_size, num_curves, length, device=device
    )

    value_mask = torch.ones_like(logs, dtype=torch.bool)
    value_mask[:, 1, 24:48] = False
    value_mask[::2, 4, :] = False
    logs = logs.masked_fill(~value_mask, 0.0)
    curve_mask = value_mask.any(dim=-1).float()
    return logs, curve_mask, value_mask.float()


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--steps", type=int, default=30)
    parser.add_argument("--device", default="cuda")
    args = parser.parse_args()

    torch.manual_seed(7)
    device = args.device if args.device == "cpu" or torch.cuda.is_available() else "cpu"
    model = WLFMWellLogEncoder1D(
        num_curves=9,
        patch_len=32,
        patch_stride=16,
        embed_dim=64,
        vq_embed_dim=64,
        num_embeddings=64,
        num_layers=2,
        num_heads=4,
        max_seq_len=128,
        use_physics_constraint=False,
    ).to(device)
    optimizer = torch.optim.AdamW(model.parameters(), lr=3e-4, weight_decay=1e-3)
    logs, curve_mask, value_mask = build_batch(16, 9, 128, device)

    losses = []
    model.train()
    for step in range(args.steps):
        output = model.forward_mwm(
            logs,
            mask_ratio=0.4,
            curve_mask=curve_mask,
            value_mask=value_mask,
            vq_loss_weight=0.1,
        )
        loss = output["loss"]
        if not torch.isfinite(loss):
            raise RuntimeError(f"non-finite loss at step {step}: {loss.item()}")
        optimizer.zero_grad(set_to_none=True)
        loss.backward()
        torch.nn.utils.clip_grad_norm_(model.parameters(), 1.0)
        optimizer.step()
        losses.append(loss.item())
        if step == 0 or (step + 1) % 5 == 0:
            print(
                f"step={step + 1:03d} loss={loss.item():.4f} "
                f"recon={output['reconstruction_loss'].item():.4f} "
                f"vq={output['vq_loss'].item():.4f} "
                f"ppl={output['perplexity'].item():.1f} "
                f"codes={output['active_codes'].item():.0f}"
            )

    window = min(5, len(losses))
    print(f"first_mean={sum(losses[:window]) / window:.4f}")
    print(f"last_mean={sum(losses[-window:]) / window:.4f}")
    print("WLFM masked-reconstruction smoke test finished.")


if __name__ == "__main__":
    main()
