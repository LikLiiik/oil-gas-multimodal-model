"""Pretrain the WLFM encoder directly from one or more LAS directories."""

from __future__ import annotations

import argparse
import random
import sys
from pathlib import Path
from typing import Dict

import torch
from torch.utils.data import DataLoader

PROJECT_ROOT = Path(__file__).parent.parent
sys.path.insert(0, str(PROJECT_ROOT))

from data.well_log_folder_dataset import WellLogFolderDataset, discover_las_files
from models.wlfm_well_log_encoder import WLFMWellLogEncoder1D


def parse_args():
    parser = argparse.ArgumentParser(description="WLFM pretraining from LAS folders")
    parser.add_argument("--las-roots", nargs="+", required=True)
    parser.add_argument("--output-dir", default="checkpoints/well_pretrain")
    parser.add_argument("--epochs", type=int, default=20)
    parser.add_argument("--batch-size", type=int, default=16)
    parser.add_argument("--num-workers", type=int, default=0)
    parser.add_argument("--log-interval", type=int, default=100)
    parser.add_argument("--sequence-length", type=int, default=128)
    parser.add_argument("--stride", type=int, default=64)
    parser.add_argument("--val-ratio", type=float, default=0.2)
    parser.add_argument("--min-curves", type=int, default=2)
    parser.add_argument("--mask-ratio", type=float, default=0.4)
    parser.add_argument("--vq-loss-weight", type=float, default=0.1)
    parser.add_argument("--codebook-size", type=int, default=128)
    parser.add_argument("--embed-dim", type=int, default=192)
    parser.add_argument("--num-layers", type=int, default=4)
    parser.add_argument("--num-heads", type=int, default=6)
    parser.add_argument("--lr", type=float, default=1e-4)
    parser.add_argument("--weight-decay", type=float, default=1e-3)
    parser.add_argument("--seed", type=int, default=42)
    parser.add_argument("--device", default="cuda")
    parser.add_argument("--resume")
    return parser.parse_args()


def split_files(files, val_ratio: float, seed: int):
    files = list(files)
    random.Random(seed).shuffle(files)
    n_val = max(1, int(round(len(files) * val_ratio))) if len(files) > 1 else 0
    return files[n_val:], files[:n_val]


def move_batch(batch: Dict, device: str):
    return {
        key: value.to(device) if torch.is_tensor(value) else value
        for key, value in batch.items()
    }


def run_epoch(
    model, loader, device, mask_ratio, vq_weight,
    optimizer=None, scaler=None, log_interval=100, phase="train",
):
    training = optimizer is not None
    device_type = torch.device(device).type
    model.train(training)
    totals = {key: 0.0 for key in ("loss", "recon", "vq", "ppl", "codes", "supervision")}
    count = 0

    context = torch.enable_grad if training else torch.no_grad
    with context():
        for batch_idx, batch in enumerate(loader):
            batch = move_batch(batch, device)
            with torch.amp.autocast(device_type=device_type, enabled=scaler is not None):
                output = model.forward_mwm(
                    batch["well_log"],
                    mask_ratio=mask_ratio,
                    curve_mask=batch["curve_mask"],
                    value_mask=batch["value_mask"],
                    vq_loss_weight=vq_weight,
                )
                loss = output["loss"]

            if not torch.isfinite(loss):
                raise RuntimeError(f"non-finite well loss: {loss.item()}")
            if training:
                optimizer.zero_grad(set_to_none=True)
                if scaler is not None:
                    scaler.scale(loss).backward()
                    scaler.unscale_(optimizer)
                    torch.nn.utils.clip_grad_norm_(model.parameters(), 1.0)
                    scaler.step(optimizer)
                    scaler.update()
                else:
                    loss.backward()
                    torch.nn.utils.clip_grad_norm_(model.parameters(), 1.0)
                    optimizer.step()

            batch_size = batch["well_log"].shape[0]
            totals["loss"] += loss.item() * batch_size
            totals["recon"] += output["reconstruction_loss"].item() * batch_size
            totals["vq"] += output["vq_loss"].item() * batch_size
            totals["ppl"] += output["perplexity"].item() * batch_size
            totals["codes"] += output["active_codes"].item() * batch_size
            totals["supervision"] += output["supervised_fraction"].item() * batch_size
            count += batch_size

            if log_interval > 0 and (
                (batch_idx + 1) % log_interval == 0 or batch_idx + 1 == len(loader)
            ):
                print(
                    f"  {phase} batch {batch_idx + 1:04d}/{len(loader):04d} | "
                    f"loss={totals['loss'] / count:.4f} "
                    f"recon={totals['recon'] / count:.4f} "
                    f"ppl={totals['ppl'] / count:.1f} "
                    f"codes={totals['codes'] / count:.1f}",
                    flush=True,
                )

    return {key: value / max(count, 1) for key, value in totals.items()}


def save_checkpoint(path, model, optimizer, epoch, best_val, args):
    torch.save({
        "model_state_dict": model.state_dict(),
        "optimizer_state_dict": optimizer.state_dict(),
        "epoch": epoch,
        "best_val_loss": best_val,
        "config": {
            "num_curves": 9,
            "embed_dim": args.embed_dim,
            "vq_embed_dim": 256,
            "num_embeddings": args.codebook_size,
            "num_layers": args.num_layers,
            "num_heads": args.num_heads,
            "mlp_ratio": 4.0,
            "patch_len": 32,
            "patch_stride": 16,
        },
    }, path)


def main():
    args = parse_args()
    torch.manual_seed(args.seed)
    device = args.device if args.device == "cpu" or torch.cuda.is_available() else "cpu"
    output_dir = Path(args.output_dir).expanduser().resolve()
    output_dir.mkdir(parents=True, exist_ok=True)

    files = discover_las_files(args.las_roots)
    if not files:
        raise SystemExit("No LAS files found under --las-roots")
    train_files, val_files = split_files(files, args.val_ratio, args.seed)
    train_ds = WellLogFolderDataset(
        train_files, args.sequence_length, args.stride, args.min_curves
    )
    val_ds = WellLogFolderDataset(
        val_files, args.sequence_length, args.stride, args.min_curves
    ) if val_files else None
    print(f"LAS files: train={len(train_files)} val={len(val_files)}")
    print(f"Windows: train={len(train_ds)} val={len(val_ds) if val_ds else 0}")

    train_loader = DataLoader(
        train_ds, batch_size=args.batch_size, shuffle=True,
        num_workers=args.num_workers, drop_last=True, pin_memory=device == "cuda",
    )
    val_loader = DataLoader(
        val_ds, batch_size=args.batch_size, shuffle=False,
        num_workers=args.num_workers, pin_memory=device == "cuda",
    ) if val_ds else None

    model = WLFMWellLogEncoder1D(
        num_curves=9,
        patch_len=32,
        patch_stride=16,
        embed_dim=args.embed_dim,
        vq_embed_dim=256,
        num_embeddings=args.codebook_size,
        num_layers=args.num_layers,
        num_heads=args.num_heads,
        max_seq_len=args.sequence_length,
    ).to(device)
    optimizer = torch.optim.AdamW(
        [p for p in model.parameters() if p.requires_grad],
        lr=args.lr, weight_decay=args.weight_decay,
    )
    device_type = torch.device(device).type
    scaler = torch.amp.GradScaler("cuda") if device_type == "cuda" else None
    start_epoch, best_val = 1, float("inf")
    if args.resume:
        checkpoint = torch.load(args.resume, map_location=device)
        model.load_state_dict(checkpoint["model_state_dict"], strict=False)
        if "optimizer_state_dict" in checkpoint:
            optimizer.load_state_dict(checkpoint["optimizer_state_dict"])
        start_epoch = checkpoint.get("epoch", 0) + 1
        best_val = checkpoint.get("best_val_loss", best_val)

    for epoch in range(start_epoch, args.epochs + 1):
        train_metrics = run_epoch(
            model, train_loader, device, args.mask_ratio,
            args.vq_loss_weight, optimizer, scaler,
            args.log_interval, "train",
        )
        val_metrics = run_epoch(
            model, val_loader, device, args.mask_ratio, args.vq_loss_weight,
            log_interval=args.log_interval, phase="val",
        ) if val_loader else train_metrics
        print(
            f"Epoch {epoch:03d}/{args.epochs} | "
            f"train={train_metrics['loss']:.4f} recon={train_metrics['recon']:.4f} "
            f"ppl={train_metrics['ppl']:.1f} codes={train_metrics['codes']:.1f} | "
            f"val={val_metrics['loss']:.4f} val_recon={val_metrics['recon']:.4f}"
        )
        save_checkpoint(output_dir / "last_well_encoder.pt", model, optimizer, epoch, best_val, args)
        if val_metrics["loss"] < best_val:
            best_val = val_metrics["loss"]
            save_checkpoint(output_dir / "best_well_encoder.pt", model, optimizer, epoch, best_val, args)

    print(f"Best checkpoint: {output_dir / 'best_well_encoder.pt'}")


if __name__ == "__main__":
    main()
